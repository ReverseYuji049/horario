import java.time.LocalDate;

public class Boleto extends Pagamento {
    
    private LocalDate dataVencimento;
    
    public Boleto(double valor, LocalDate dataVencimento) {
        super(valor);
        this.dataVencimento = dataVencimento;
    }

    @Override
    public boolean validar() {
        return super.validar() && dataVencimento != null;
    }

    @Override
    public void processar() {

        if (!validar()) {
            alterarStatus("RECUSADO");
            return;
        }

        if (LocalDate.now().isAfter(dataVencimento)) {
            alterarStatus("VENCIDO");
            System.out.println("Boleto vencido.");
            return;
        }

        System.out.println("Processando boleto...");
        alterarStatus("APROVADO");
    }

    @Override
    public double calcularTaxa() {
        return getValor() * 0.01;
    }
    
}