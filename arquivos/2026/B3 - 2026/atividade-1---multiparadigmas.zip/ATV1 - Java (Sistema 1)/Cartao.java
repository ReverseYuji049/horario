public class Cartao extends Pagamento {
    
    private int parcelas;
    
    public Cartao(double valor, int parcelas) {
        super(valor);
        this.parcelas = parcelas;
    }
    
    public int getParcelas() {
        return parcelas;
    }
    
    @Override     
    public boolean validar () {
        return super.validar() && parcelas > 0;
    }
    
    @Override
    public void processar() {
        if (!validar()) {
            alterarStatus("RECUSADO");
            return;
        }

        System.out.println("Processando pagamento com cartão...");
        System.out.println("Parcelas: " + parcelas);

        alterarStatus("APROVADO");
    }
    
    @Override 
    public double calcularTaxa() {
        return getValor() * parcelas; 
    }
}