public class CarteiraDigital extends Pagamento {
    
    private double saldo;

    public CarteiraDigital(double valor, double saldo) {
        super(valor);
        this.saldo = saldo;
    }

    @Override
    public boolean validar() {
        return super.validar() && saldo >= super.getValor();
    }

    @Override
    public void processar() {

        if (!validar()) {
            alterarStatus("RECUSADO");
            System.out.println("Saldo insuficiente.");
            return;
        }

        System.out.println("Processando pagamento pela carteira digital...");

        saldo -= super.getValor();

        alterarStatus("APROVADO");
    }

    @Override
    public double calcularTaxa() {
        return super.getValor() * 0.015;
    }
}