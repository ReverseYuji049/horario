public class Criptomoeda extends Pagamento {
    
    private String carteira;
    
    public Criptomoeda(double valor, String carteira) {
        super(valor);
        this.carteira = carteira;
    }

    @Override
    public boolean validar() {
        return super.validar()
                && carteira != null
                && !carteira.isBlank();
    }

    @Override
    public void processar() {

        if (!validar()) {
            alterarStatus("RECUSADO");
            return;
        }

        System.out.println("Processando pagamento com criptomoeda...");
        System.out.println("Carteira: " + carteira);

        alterarStatus("APROVADO");
    }

    @Override
    public double calcularTaxa() {
        return getValor() * 0.01;
    }
}