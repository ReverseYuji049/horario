import java.util.ArrayList;

public class Main {
	public static void main(String[] args) {
	    
	    long inicio = System.nanoTime();
	 
        ArrayList<Pagamento> pagamentos = new ArrayList<>();
        
        pagamentos.add(new Cartao(1000.00, 3));
        
        pagamentos.add(new Pix(500.0, "usuario@gmail.com"));
        
        pagamentos.add(new CarteiraDigital(200.00, 500.00));
        
        for (Pagamento pagamento : pagamentos) {
            System.out.println("==============================");
            System.out.println("Pagamento: " + pagamento.getClass().getSimpleName());
            System.out.println("Valor: R$ " + pagamento.getValor());

            if (pagamento.validar()) {
                double taxa = pagamento.calcularTaxa();
                System.out.println("Taxa: R$ " + taxa);
                pagamento.processar();
            } else {
                System.out.println("Pagamento inválido.");
            }
            System.out.println("Status: " + pagamento.getStatus());
        }

        System.out.println("==============================");
        
        long fim = System.nanoTime();
        long tempo = fim - inicio;
        System.out.printf("Tempo de execução: %d ns%n", tempo);
        
	}
}
