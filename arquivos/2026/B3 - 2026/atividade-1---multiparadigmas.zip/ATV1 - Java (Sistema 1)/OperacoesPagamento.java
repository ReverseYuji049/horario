public interface OperacoesPagamento {
    boolean validar();

    void processar();

    double calcularTaxa();

    String getStatus();
}