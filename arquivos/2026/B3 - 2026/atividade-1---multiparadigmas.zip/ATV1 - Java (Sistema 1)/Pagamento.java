public abstract class Pagamento implements OperacoesPagamento {
    
    private double valor;
    private String status;
    
    public Pagamento (double valor) {
        this.valor = valor;
        this.status = "PENDENTE";
    }
    
    public double getValor() {
        return valor;
    }

    public String getStatus() {
        return status;
    }
    
    protected void alterarStatus(String status) {
        this.status = status;
    }
    
    @Override     
    public boolean validar () {
        return valor > 0;
    }
    
    @Override
    public abstract void processar();
    
    @Override 
    public abstract double calcularTaxa();
}