public class Pix extends Pagamento {
    
    private String chave;
    
    public Pix (double valor, String chave) {
        super(valor);
        this.chave = chave;
    }
    
    @Override
    public boolean validar() {
        return super.validar() && chave != null && !chave.isBlank();
    }

    @Override
    public void processar() {
        if (!validar()) {
            alterarStatus("RECUSADO");
            return;
        }

        System.out.println("Processando pagamento via PIX...");
        System.out.println("Chave Pix: " + chave);

        alterarStatus("APROVADO");
        
    }

    @Override
    public double calcularTaxa() {
        return 0;
    }
}