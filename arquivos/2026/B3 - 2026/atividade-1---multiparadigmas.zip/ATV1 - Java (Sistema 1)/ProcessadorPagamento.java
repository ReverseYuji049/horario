public class ProcessadorPagamento {

    private Pagamento pagamento;

    public ProcessadorPagamento(Pagamento pagamento) {
        this.pagamento = pagamento;
    }

    public void executar() {

        System.out.println("Valor: R$ " + pagamento.getValor());

        if (pagamento.validar()) {

            System.out.println("Taxa: R$ " + pagamento.calcularTaxa());

            pagamento.processar();

            System.out.println("Status: " + pagamento.getStatus());

        } else {

            System.out.println("Pagamento inválido.");
        }
    }
}