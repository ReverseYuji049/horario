import java.util.*;

public class AnaliseVendas {

    private List<Venda> vendas;

    public AnaliseVendas(List<Venda> vendas) {
        this.vendas = vendas;
    }

    public double calcularFaturamentoTotal() {

        double total = 0;

        for (Venda venda : vendas) {
            total += venda.getFaturamento();
        }

        return total;
    }

    public Map<String, Double> calcularFaturamentoPorProduto() {

        Map<String, Double> resultado = new HashMap<>();

        for (Venda venda : vendas) {
            String produto = venda.getCodigoProduto();

            double faturamento = venda.getFaturamento();

            resultado.put(produto, resultado.getOrDefault(produto, 0.0) + faturamento);
        }

        return resultado;
    }

    public String getProdutoMaiorFaturamento() {

        Map<String, Double> faturamento = calcularFaturamentoPorProduto();

        String produtoMaior = null;
        double maior = 0;

        for (Map.Entry<String, Double> entrada : faturamento.entrySet()) {

            if (entrada.getValue() > maior) {
                maior = entrada.getValue();
                produtoMaior = entrada.getKey();
            }
        }

        return produtoMaior;
    }

    public Map<String, Integer> calcularQuantidadePorProduto() {

        Map<String, Integer> resultado = new HashMap<>();

        for (Venda venda : vendas) {

            String produto = venda.getCodigoProduto();

            resultado.put(produto, resultado.getOrDefault(produto, 0) + venda.getQtd());
        }

        return resultado;
    }

    public List<String> getCincoProdutosMaisVendidos() {

        Map<String, Integer> quantidade = calcularQuantidadePorProduto();

        List<Map.Entry<String, Integer>> lista = new ArrayList<>(quantidade.entrySet());

        lista.sort(Comparator.comparing(Map.Entry<String, Integer>::getValue).reversed());

        List<String> resultado = new ArrayList<>();

        int limite = Math.min(5, lista.size());

        for (int i = 0; i < limite; i++) {
            resultado.add(lista.get(i).getKey());
        }

        return resultado;
    }

    public Map<String, Double> calcularFaturamentoPorCategoria() {

        Map<String, Double> resultado = new HashMap<>();

        for (Venda venda : vendas) {
            String categoria = venda.getCategoria();

            resultado.put(categoria, resultado.getOrDefault(categoria, 0.0) + venda.getFaturamento());
        }

        return resultado;
    }

    public String getCategoriaMaiorFaturamento() {

        Map<String, Double> faturamento = calcularFaturamentoPorCategoria();

        String categoriaMaior = null;
        double maior = 0;

        for (Map.Entry<String, Double> entrada : faturamento.entrySet()) {

            if (entrada.getValue() > maior) {
                maior = entrada.getValue();
                categoriaMaior = entrada.getKey();
            }
        }
        return categoriaMaior;
    }

    public double calcularTicketMedio() {

        if (vendas.isEmpty()) {
            return 0;
        }

        return calcularFaturamentoTotal()
                / vendas.size();
    }

    public Map<String, Double> calcularFaturamentoPorCidade() {

        Map<String, Double> resultado = new HashMap<>();

        for (Venda venda : vendas) {

            String cidade = venda.getCidade();

            resultado.put(cidade, resultado.getOrDefault(cidade, 0.0) + venda.getFaturamento());
        }

        return resultado;
    }

    public String getCidadeMaiorFaturamento() {

        Map<String, Double> faturamento = calcularFaturamentoPorCidade();

        String cidadeMaior = null;
        double maior = 0;

        for (Map.Entry<String, Double> entrada : faturamento.entrySet()) {

            if (entrada.getValue() > maior) {
                maior = entrada.getValue();
                cidadeMaior = entrada.getKey();
            }
        }

        return cidadeMaior;
    }

    public Map<String, Double> calcularFaturamentoPorEstado() {

        Map<String, Double> resultado = new HashMap<>();

        for (Venda venda : vendas) {
            String estado = venda.getEstado();

            resultado.put(estado, resultado.getOrDefault(estado, 0.0) + venda.getFaturamento()
            );
        }

        return resultado;
    }

    public String getEstadoMaiorFaturamento() {

        Map<String, Double> faturamento = calcularFaturamentoPorEstado();

        String estadoMaior = null;
        double maior = 0;

        for (Map.Entry<String, Double> entrada : faturamento.entrySet()) {
            if (entrada.getValue() > maior) {
                maior = entrada.getValue();
                estadoMaior = entrada.getKey();
            }
        }

        return estadoMaior;
    }

    public Map<String, Double> calcularFaturamentoPorMes() {

        Map<String, Double> resultado = new HashMap<>();

        for (Venda venda : vendas) {
            String mes = venda.getData().getYear() + "-" + String.format("%02d", venda.getData().getMonthValue());

            resultado.put(mes, resultado.getOrDefault(mes, 0.0) + venda.getFaturamento());
        }

        return resultado;
    }

    public Map<String, Integer> calcularQuantidadePorCategoria() {

        Map<String, Integer> resultado = new HashMap<>();

        for (Venda venda : vendas) {

            String categoria = venda.getCategoria();

            resultado.put(categoria, resultado.getOrDefault(categoria, 0) + venda.getQtd());
        }

        return resultado;
    }

    public double calcularMediaFaturamentoProdutos() {

        Map<String, Double> faturamento = calcularFaturamentoPorProduto();

        if (faturamento.isEmpty()) {
            return 0;
        }

        double total = 0;

        for (double valor : faturamento.values()) {
            total += valor;
        }

        return total / faturamento.size();
    }

    public List<String> getProdutosAcimaDaMedia() {

        Map<String, Double> faturamento = calcularFaturamentoPorProduto();

        double media = calcularMediaFaturamentoProdutos();

        List<String> resultado = new ArrayList<>();

        for (Map.Entry<String, Double> entrada : faturamento.entrySet()) {

            if (entrada.getValue() > media) {
                resultado.add(entrada.getKey());
            }
        }

        return resultado;
    }
}
