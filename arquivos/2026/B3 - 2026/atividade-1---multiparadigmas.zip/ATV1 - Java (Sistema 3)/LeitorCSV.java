import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class LeitorCSV {

    public List<Venda> carregarVendas(String nomeArquivo) throws IOException {

        List<Venda> vendas = new ArrayList<>();

        DateTimeFormatter formato = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        BufferedReader leitor = new BufferedReader(new FileReader(nomeArquivo));

        leitor.readLine();

        String linha;

        while ((linha = leitor.readLine()) != null) {

            String[] dados = linha.split(",");

            int codigoVenda =
                    Integer.parseInt(dados[0]);

            LocalDate data =
                    LocalDate.parse(dados[1], formato);

            String codigoProduto = dados[2];

            String descricao = dados[3];

            String categoria = dados[4];

            int qtd = Integer.parseInt(dados[5]);

            double valorUnitario = Double.parseDouble(dados[6]);

            String cidade = dados[7];

            String estado = dados[8];

            Venda venda = new Venda(codigoVenda, data, codigoProduto, descricao,
                    categoria, qtd, valorUnitario, cidade, estado);

            vendas.add(venda);
        }

        leitor.close();

        return vendas;
    }
}
