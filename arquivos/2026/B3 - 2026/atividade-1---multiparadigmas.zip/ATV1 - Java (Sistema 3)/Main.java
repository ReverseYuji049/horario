import java.util.List;
import java.util.Map;

public class Main {
	public static void main(String[] args) {
		
		try {

            long inicio = System.nanoTime();

            LeitorCSV leitor = new LeitorCSV();

            java.util.List<Venda> vendas = leitor.carregarVendas("vendas.csv");

            AnaliseVendas analisador = new AnaliseVendas(vendas);

            double faturamentoTotal = analisador.calcularFaturamentoTotal();

            String produtoMaior = analisador.getProdutoMaiorFaturamento();

            List<String> cincoMaisVendidos = analisador.getCincoProdutosMaisVendidos();

            String categoriaMaior = analisador.getCategoriaMaiorFaturamento();

            double ticketMedio = analisador.calcularTicketMedio();

            String cidadeMaior = analisador.getCidadeMaiorFaturamento();

            String estadoMaior = analisador.getEstadoMaiorFaturamento();

            Map<String, Double> faturamentoMes = analisador.calcularFaturamentoPorMes();

            Map<String, Integer> quantidadeCategoria = analisador.calcularQuantidadePorCategoria();

            List<String> produtosAcimaMedia = analisador.getProdutosAcimaDaMedia();

            long fim = System.nanoTime();

            long tempo = fim - inicio;

            double tempoMs =
                    tempo / 1_000_000.0;

            System.out.println("===== RESULTADOS =====");

            System.out.printf("Registros: %d%n", vendas.size());
            System.out.printf("1. Faturamento total: R$ %.2f%n", faturamentoTotal);

            System.out.println("2. Produto com maior faturamento: " + produtoMaior);

            System.out.println("3. Cinco produtos mais vendidos:");

            for (String produto : cincoMaisVendidos) {
                System.out.println("- " + produto);
            }

            System.out.println("4. Categoria com maior faturamento: " + categoriaMaior);
            System.out.printf("5. Ticket médio: R$ %.2f%n", ticketMedio);
            System.out.println("6. Cidade com maior faturamento: " + cidadeMaior);

            System.out.println("7. Estado com maior faturamento: " + estadoMaior);
            System.out.println("8. Faturamento por mês:");

            for (Map.Entry<String, Double> entrada : faturamentoMes.entrySet()) {

                System.out.printf("%s: R$ %.2f%n", entrada.getKey(), entrada.getValue());
            }

            System.out.println("9. Quantidade por categoria:");

            for (Map.Entry<String, Integer> entrada : quantidadeCategoria.entrySet()) {

                System.out.printf("%s: %d unidades%n", entrada.getKey(), entrada.getValue());
            }

            System.out.println("10. Produtos acima da média:"
            );

            for (String produto : produtosAcimaMedia) {
                System.out.println("- " + produto);
            }

            System.out.printf("Tempo de execução: %.6f ms%n", tempoMs
            );

        } catch (Exception e) {

            System.out.println("Erro: " + e.getMessage());
        }
	}
}
