import java.time.LocalDate;

public class Venda {

    private int codigoVenda;
    private LocalDate data;
    private String codigoProduto;
    private String descricao;
    private String categoria;
    private int qtd;
    private double valorUnitario;
    private String cidade;
    private String estado;

    public Venda(int codigoVenda, LocalDate data, String codigoProduto, String descricao, String categoria,
                int qtd, double valorUnitario, String cidade, String estado) {
        this.codigoVenda = codigoVenda;
        this.data = data;
        this.codigoProduto = codigoProduto;
        this.descricao = descricao;
        this.categoria = categoria;
        this.qtd = qtd;
        this.valorUnitario = valorUnitario;
        this.cidade = cidade;
        this.estado = estado;
    }

    public int getCodigoVenda() {
        return codigoVenda;
    }

    public void setCodigoVenda(int codigoVenda) {
        this.codigoVenda = codigoVenda;
    }

    public LocalDate getData() {
        return data;
    }

    public void setData(LocalDate data) {
        this.data = data;
    }

    public String getCodigoProduto() {
        return codigoProduto;
    }

    public void setCodigoProduto(String codigoProduto) {
        this.codigoProduto = codigoProduto;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public int getQtd() {
        return qtd;
    }

    public void setQtd(int qtd) {
        this.qtd = qtd;
    }

    public double getValorUnitario() {
        return valorUnitario;
    }

    public void setValorUnitario(double valorUnitario) {
        this.valorUnitario = valorUnitario;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public double getFaturamento() {
        return qtd * valorUnitario;
    }
}
