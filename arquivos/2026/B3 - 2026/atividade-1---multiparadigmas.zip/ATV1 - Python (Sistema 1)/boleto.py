from pagamento import Pagamento
from datetime import date


class Boleto(Pagamento):

    def __init__(self, valor, descricao, data_vencimento):
        super().__init__(valor, descricao)

        self.__data_vencimento = data_vencimento

    @property
    def data_vencimento(self):
        return self.__data_vencimento

    def validar_pagamento(self):

        return (
            self.valor > 0
            and self.data_vencimento >= date.today()
        )

    def processar_pagamento(self):

        if self.validar_pagamento():
            self.alterar_status("PROCESSADO")
            return True

        self.alterar_status("RECUSADO")
        return False

    def calcular_taxa(self):

        return 0.01 * self.valor