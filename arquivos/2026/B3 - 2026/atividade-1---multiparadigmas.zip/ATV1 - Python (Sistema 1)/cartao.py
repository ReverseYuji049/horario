from pagamento import Pagamento


class Cartao(Pagamento):

    def __init__(self, valor, descricao, parcelas):
        super().__init__(valor, descricao)

        self.__parcelas = parcelas

    @property
    def parcelas(self):
        return self.__parcelas

    def validar_pagamento(self):

        return self.valor > 0 and self.parcelas > 0

    def processar_pagamento(self):

        if self.validar_pagamento():
            self.alterar_status("PROCESSADO")
            return True

        self.alterar_status("RECUSADO")
        return False

    def calcular_taxa(self):

        return self.valor * 0.03