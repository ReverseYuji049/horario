from pagamento import Pagamento


class CarteiraDigital(Pagamento):

    def __init__(self, valor, descricao, saldo):
        super().__init__(valor, descricao)

        self.__saldo = saldo

    @property
    def saldo(self):
        return self.__saldo

    def validar_pagamento(self):

        return (
            self.valor > 0
            and self.saldo >= self.valor
        )

    def processar_pagamento(self):

        if self.validar_pagamento():

            self.__saldo -= self.valor

            self.alterar_status("PROCESSADO")

            return True

        self.alterar_status("RECUSADO")
        return False

    def calcular_taxa(self):

        return self.valor * 0.01