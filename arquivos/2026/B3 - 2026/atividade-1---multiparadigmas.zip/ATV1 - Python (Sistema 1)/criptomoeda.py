from pagamento import Pagamento


class Criptomoeda(Pagamento):

    def __init__(self, valor, descricao, carteira):
        super().__init__(valor, descricao)

        self.__carteira = carteira

    @property
    def carteira(self):
        return self.__carteira

    def validar_pagamento(self):

        return (
            self.valor > 0
            and self.carteira != ""
        )

    def processar_pagamento(self):

        if self.validar_pagamento():
            self.alterar_status("PROCESSADO")
            return True

        self.alterar_status("RECUSADO")
        return False

    def calcular_taxa(self):

        return self.valor * 0.02