from datetime import date
import time

from cartao import Cartao
from pix import Pix
from boleto import Boleto
from carteira_digital import CarteiraDigital
from criptomoeda import Criptomoeda


def main():

    inicio = time.perf_counter_ns()

    pagamentos = [
        Cartao(
            1000.00,
            "Compra no cartão",
            3
        ),

        Pix(
            500.00,
            "Compra via PIX",
            "chave-pix-123"
        ),

        Boleto(
            750.00,
            "Pagamento de boleto",
            date(2026, 12, 31)
        ),

        CarteiraDigital(
            300.00,
            "Compra na carteira",
            1000.00
        ),

        Criptomoeda(
            2000.00,
            "Compra com criptomoeda",
            "0xABC123"
        )
    ]


    for pagamento in pagamentos:

        print(
            f"\nPagamento: "
            f"{pagamento.descricao}"
        )

        print(
            f"Valor: R$ "
            f"{pagamento.valor:.2f}"
        )

        print(
            f"Taxa: R$ "
            f"{pagamento.calcular_taxa():.2f}"
        )

        pagamento.processar_pagamento()

        print(
            f"Status: "
            f"{pagamento.get_status()}"
        )


    fim = time.perf_counter_ns()

    tempo = fim - inicio
    tempo_ms = tempo / 1_000_000


    print("\n===== TEMPO DE EXECUÇÃO =====")

    print(
        f"{tempo} ns"
    )

    print(
        f"{tempo_ms:.6f} ms"
    )


if __name__ == "__main__":
    main()