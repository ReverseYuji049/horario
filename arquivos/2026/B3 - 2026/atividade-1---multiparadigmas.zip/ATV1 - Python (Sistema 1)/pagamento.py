from abc import ABC, abstractmethod


class Transacao:

    def __init__(self, status="PENDENTE"):
        self.status = status

    def alterar_status(self, status):
        self.status = status

    def get_status(self):
        return self.status


class Pagamento(ABC):

    def __init__(self, valor, descricao):
        self.__valor = valor
        self.__descricao = descricao

        # Composição:
        self.__transacao = Transacao()

    @property
    def valor(self):
        return self.__valor

    @property
    def descricao(self):
        return self.__descricao

    def get_status(self):
        return self.__transacao.get_status()

    def alterar_status(self, status):
        self.__transacao.alterar_status(status)

    @abstractmethod
    def validar_pagamento(self):
        pass

    @abstractmethod
    def processar_pagamento(self):
        pass

    @abstractmethod
    def calcular_taxa(self):
        pass