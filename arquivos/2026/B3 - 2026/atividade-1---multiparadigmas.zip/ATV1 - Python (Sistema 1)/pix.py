from pagamento import Pagamento


class Pix(Pagamento):

    def __init__(self, valor, descricao, chave):
        super().__init__(valor, descricao)

        self.__chave = chave

    @property
    def chave(self):
        return self.__chave

    def validar_pagamento(self):

        return (
            self.valor > 0
            and self.chave != ""
        )

    def processar_pagamento(self):

        if self.validar_pagamento():
            self.alterar_status("PROCESSADO")
            return True

        self.alterar_status("RECUSADO")
        return False

    def calcular_taxa(self):

        return 0.0