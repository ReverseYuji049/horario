from collections import defaultdict


class AnalisadorVendas:

    def __init__(self, vendas):
        self.vendas = vendas

    # ==========================================
    # 1. FATURAMENTO TOTAL
    # ==========================================

    def calcular_faturamento_total(self):

        return sum(
            venda.get_faturamento()
            for venda in self.vendas
        )


    # ==========================================
    # 2. FATURAMENTO POR PRODUTO
    # ==========================================

    def calcular_faturamento_por_produto(self):

        resultado = defaultdict(float)

        for venda in self.vendas:
            resultado[venda.codigo_produto] += \
                venda.get_faturamento()

        return dict(resultado)


    # ==========================================
    # 2. PRODUTO COM MAIOR FATURAMENTO
    # ==========================================

    def get_produto_maior_faturamento(self):

        faturamento = \
            self.calcular_faturamento_por_produto()

        return max(
            faturamento,
            key=faturamento.get
        )


    # ==========================================
    # QUANTIDADE POR PRODUTO
    # ==========================================

    def calcular_quantidade_por_produto(self):

        resultado = defaultdict(int)

        for venda in self.vendas:
            resultado[venda.codigo_produto] += \
                venda.quantidade

        return dict(resultado)


    # ==========================================
    # 3. CINCO PRODUTOS MAIS VENDIDOS
    # ==========================================

    def get_cinco_produtos_mais_vendidos(self):

        quantidade = \
            self.calcular_quantidade_por_produto()

        produtos = sorted(
            quantidade.items(),
            key=lambda item: item[1],
            reverse=True
        )

        return produtos[:5]


    # ==========================================
    # 4. FATURAMENTO POR CATEGORIA
    # ==========================================

    def calcular_faturamento_por_categoria(self):

        resultado = defaultdict(float)

        for venda in self.vendas:
            resultado[venda.categoria] += \
                venda.get_faturamento()

        return dict(resultado)


    # ==========================================
    # 4. CATEGORIA COM MAIOR FATURAMENTO
    # ==========================================

    def get_categoria_maior_faturamento(self):

        faturamento = \
            self.calcular_faturamento_por_categoria()

        return max(
            faturamento,
            key=faturamento.get
        )


    # ==========================================
    # 5. TICKET MÉDIO
    # ==========================================

    def calcular_ticket_medio(self):

        if not self.vendas:
            return 0

        return (
            self.calcular_faturamento_total()
            / len(self.vendas)
        )


    # ==========================================
    # 6. FATURAMENTO POR CIDADE
    # ==========================================

    def calcular_faturamento_por_cidade(self):

        resultado = defaultdict(float)

        for venda in self.vendas:
            resultado[venda.cidade] += \
                venda.get_faturamento()

        return dict(resultado)


    # ==========================================
    # 6. CIDADE COM MAIOR FATURAMENTO
    # ==========================================

    def get_cidade_maior_faturamento(self):

        faturamento = \
            self.calcular_faturamento_por_cidade()

        return max(
            faturamento,
            key=faturamento.get
        )


    # ==========================================
    # 7. FATURAMENTO POR ESTADO
    # ==========================================

    def calcular_faturamento_por_estado(self):

        resultado = defaultdict(float)

        for venda in self.vendas:
            resultado[venda.estado] += \
                venda.get_faturamento()

        return dict(resultado)


    # ==========================================
    # 7. ESTADO COM MAIOR FATURAMENTO
    # ==========================================

    def get_estado_maior_faturamento(self):

        faturamento = \
            self.calcular_faturamento_por_estado()

        return max(
            faturamento,
            key=faturamento.get
        )


    # ==========================================
    # 8. FATURAMENTO POR MÊS
    # ==========================================

    def calcular_faturamento_por_mes(self):

        resultado = defaultdict(float)

        for venda in self.vendas:

            mes = venda.data.strftime("%Y-%m")

            resultado[mes] += \
                venda.get_faturamento()

        return dict(resultado)


    # ==========================================
    # 9. QUANTIDADE POR CATEGORIA
    # ==========================================

    def calcular_quantidade_por_categoria(self):

        resultado = defaultdict(int)

        for venda in self.vendas:
            resultado[venda.categoria] += \
                venda.quantidade

        return dict(resultado)


    # ==========================================
    # 10. MÉDIA DE FATURAMENTO DOS PRODUTOS
    # ==========================================

    def calcular_media_faturamento_produtos(self):

        faturamento = \
            self.calcular_faturamento_por_produto()

        if not faturamento:
            return 0

        return (
            sum(faturamento.values())
            / len(faturamento)
        )


    # ==========================================
    # 10. PRODUTOS ACIMA DA MÉDIA
    # ==========================================

    def get_produtos_acima_da_media(self):

        faturamento = \
            self.calcular_faturamento_por_produto()

        media = \
            self.calcular_media_faturamento_produtos()

        return [
            produto
            for produto, valor in faturamento.items()
            if valor > media
        ]