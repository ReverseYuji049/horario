import csv
from datetime import datetime
from venda import Venda


def carregar_vendas(nome_arquivo):

    vendas = []

    with open(nome_arquivo, "r", encoding="utf-8") as arquivo:

        leitor = csv.DictReader(arquivo)

        for linha in leitor:

            venda = Venda(
                int(linha["codigo_venda"]),
                datetime.strptime(
                    linha["data"],
                    "%Y-%m-%d"
                ).date(),
                linha["codigo_produto"],
                linha["descricao"],
                linha["categoria"],
                int(linha["quantidade"]),
                float(linha["valor_unitario"]),
                linha["cidade"],
                linha["estado"]
            )

            vendas.append(venda)

    return vendas