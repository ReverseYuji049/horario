from leitor_csv import carregar_vendas
from analisador_vendas import AnalisadorVendas
import time


def main():

    inicio = time.perf_counter_ns()

    vendas = carregar_vendas("vendas.csv")

    analisador = AnalisadorVendas(vendas)

    faturamento_total = \
        analisador.calcular_faturamento_total()

    produto_maior = \
        analisador.get_produto_maior_faturamento()

    cinco_mais_vendidos = \
        analisador.get_cinco_produtos_mais_vendidos()

    categoria_maior = \
        analisador.get_categoria_maior_faturamento()

    ticket_medio = \
        analisador.calcular_ticket_medio()

    cidade_maior = \
        analisador.get_cidade_maior_faturamento()

    estado_maior = \
        analisador.get_estado_maior_faturamento()

    faturamento_mes = \
        analisador.calcular_faturamento_por_mes()

    quantidade_categoria = \
        analisador.calcular_quantidade_por_categoria()

    produtos_acima_media = \
        analisador.get_produtos_acima_da_media()


    fim = time.perf_counter_ns()

    tempo = fim - inicio

    tempo_ms = tempo / 1_000_000

    print("===== RESULTADOS =====")

    print(
        f"Registros: {len(vendas)}"
    )

    print(
        f"1. Faturamento total: "
        f"R$ {faturamento_total:.2f}"
    )

    print(
        f"2. Produto com maior faturamento: "
        f"{produto_maior}"
    )

    print(
        "3. Cinco produtos mais vendidos:"
    )

    for produto, quantidade in cinco_mais_vendidos:
        print(
            f"- {produto}: {quantidade} unidades"
        )

    print(
        f"4. Categoria com maior faturamento: "
        f"{categoria_maior}"
    )

    print(
        f"5. Ticket médio: "
        f"R$ {ticket_medio:.2f}"
    )

    print(
        f"6. Cidade com maior faturamento: "
        f"{cidade_maior}"
    )

    print(
        f"7. Estado com maior faturamento: "
        f"{estado_maior}"
    )

    print("\n8. Faturamento por mês:")

    for mes, valor in faturamento_mes.items():
        print(
            f"{mes}: R$ {valor:.2f}"
        )

    print(
        "\n9. Quantidade vendida por categoria:"
    )

    for categoria, quantidade \
            in quantidade_categoria.items():

        print(
            f"{categoria}: {quantidade} unidades"
        )

    print(
        "\n10. Produtos acima da média:"
    )

    for produto in produtos_acima_media:
        print(f"- {produto}")


    print(
        "\n===== TEMPO DE EXECUÇÃO ====="
    )

    print(
        f"Tempo: {tempo} ns"
    )

    print(
        f"Tempo: {tempo_ms:.6f} ms"
    )


if __name__ == "__main__":
    main()