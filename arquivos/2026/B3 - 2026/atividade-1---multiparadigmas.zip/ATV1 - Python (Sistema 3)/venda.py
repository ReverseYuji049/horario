from datetime import date


class Venda:

    def __init__(
        self,
        codigo_venda: int,
        data: date,
        codigo_produto: str,
        descricao: str,
        categoria: str,
        quantidade: int,
        valor_unitario: float,
        cidade: str,
        estado: str
    ):
        self.codigo_venda = codigo_venda
        self.data = data
        self.codigo_produto = codigo_produto
        self.descricao = descricao
        self.categoria = categoria
        self.quantidade = quantidade
        self.valor_unitario = valor_unitario
        self.cidade = cidade
        self.estado = estado

    def get_faturamento(self):
        return self.quantidade * self.valor_unitario