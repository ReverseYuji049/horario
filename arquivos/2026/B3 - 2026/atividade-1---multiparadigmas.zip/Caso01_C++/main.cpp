#include <cstdio>
#include <memory>
#include <sstream>
#include <string>
#include <vector>

// =========================== StatusTransacao ===========================

enum class StatusTransacao {
    PENDENTE,
    PROCESSANDO,
    APROVADA,
    RECUSADA
};

std::string statusParaTexto(StatusTransacao status) {
    switch (status) {
        case StatusTransacao::PENDENTE:
            return "Pendente";
        case StatusTransacao::PROCESSANDO:
            return "Processando";
        case StatusTransacao::APROVADA:
            return "Aprovada";
        case StatusTransacao::RECUSADA:
            return "Recusada";
    }
    return "Desconhecido";
}

// ================================ Titular ===============================

class Titular {
public:
    Titular(const std::string& nome, const std::string& documento)
        : nome_(nome), documento_(documento) {}

    const std::string& getNome() const { return nome_; }
    const std::string& getDocumento() const { return documento_; }

private:
    std::string nome_;
    std::string documento_;
};

// ============================ DadosTransacao ============================

class DadosTransacao {
public:
    DadosTransacao(const std::string& identificador, double valor)
        : identificador_(identificador), valor_(valor) {}

    const std::string& getIdentificador() const { return identificador_; }
    double getValor() const { return valor_; }

private:
    std::string identificador_;
    double valor_;
};

// ============================== IProcessavel ==============================

class IProcessavel {
public:
    virtual ~IProcessavel() = default;

    virtual bool validar() const = 0;
    virtual void processar() = 0;
    virtual double calcularTaxa() const = 0;
    virtual StatusTransacao getStatus() const = 0;
};

// ============================= FormaPagamento =============================

class FormaPagamento : public IProcessavel {
public:
    explicit FormaPagamento(const DadosTransacao& dados)
        : dados_(dados), status_(StatusTransacao::PENDENTE) {}
    virtual ~FormaPagamento() = default;

    bool validar() const override = 0;
    void processar() override = 0;
    double calcularTaxa() const override = 0;

    StatusTransacao getStatus() const override { return status_; }
    double getValor() const { return dados_.getValor(); }
    const std::string& getIdentificador() const { return dados_.getIdentificador(); }

    virtual std::string getDescricao() const = 0;

protected:
    void definirStatus(StatusTransacao novoStatus) { status_ = novoStatus; }

private:
    DadosTransacao dados_;
    StatusTransacao status_;
};

// ============================== CartaoCredito ==============================

class CartaoCredito : public FormaPagamento {
public:
    CartaoCredito(const DadosTransacao& dados, const Titular& titular,
                  const std::string& numeroCartao, int parcelas)
        : FormaPagamento(dados),
          titular_(titular),
          numeroMascarado_(mascarar(numeroCartao)),
          parcelas_(parcelas) {}

    bool validar() const override {
        return getValor() > 0 && parcelas_ >= 1 && parcelas_ <= 12 && !numeroMascarado_.empty();
    }

    void processar() override {
        definirStatus(validar() ? StatusTransacao::APROVADA : StatusTransacao::RECUSADA);
    }

    double calcularTaxa() const override {
        double percentual = 0.02 + 0.004 * (parcelas_ - 1);
        return getValor() * percentual;
    }

    std::string getDescricao() const override {
        std::ostringstream oss;
        oss << "Cartao de Credito " << numeroMascarado_ << " (" << titular_.getNome() << ") em "
            << parcelas_ << "x";
        return oss.str();
    }

    int getParcelas() const { return parcelas_; } 

private:
    Titular titular_;
    std::string numeroMascarado_;
    int parcelas_;

    static std::string mascarar(const std::string& numeroCartao) {
        if (numeroCartao.size() < 4) {
            return "****";
        }
        return "**** **** **** " + numeroCartao.substr(numeroCartao.size() - 4);
    }
};

// ===================================== Pix =====================================

class Pix : public FormaPagamento {
public:
    Pix(const DadosTransacao& dados, const std::string& chave, const std::string& codigoTransacao)
        : FormaPagamento(dados), chave_(chave), codigoTransacao_(codigoTransacao) {}

    bool validar() const override { return getValor() > 0 && !chave_.empty(); }

    void processar() override {
        definirStatus(validar() ? StatusTransacao::APROVADA : StatusTransacao::RECUSADA);
    }

    double calcularTaxa() const override { return 0.0; } // PIX sem taxa para o pagador

    std::string getDescricao() const override {
        return "PIX (chave: " + chave_ + ", codigo: " + codigoTransacao_ + ")";
    }

    const std::string& getChave() const { return chave_; } // comportamento próprio do PIX
    const std::string& getCodigoTransacao() const { return codigoTransacao_; }

private:
    std::string chave_;
    std::string codigoTransacao_;
};

// ============================== BoletoBancario ==============================

class BoletoBancario : public FormaPagamento {
public:
    BoletoBancario(const DadosTransacao& dados, const Titular& pagador,
                   const std::string& dataVencimento, const std::string& codigoBarras)
        : FormaPagamento(dados),
          pagador_(pagador),
          dataVencimento_(dataVencimento),
          codigoBarras_(codigoBarras) {}

    bool validar() const override {
        return getValor() > 0 && !dataVencimento_.empty() && codigoBarras_.size() >= 40;
    }

    void processar() override {
        definirStatus(validar() ? StatusTransacao::PROCESSANDO : StatusTransacao::RECUSADA);
    }

    double calcularTaxa() const override { return TAXA_EMISSAO; }

    std::string getDescricao() const override {
        return "Boleto Bancario para " + pagador_.getNome() + " (vencimento: " + dataVencimento_ + ")";
    }

    const std::string& getDataVencimento() const { return dataVencimento_; } // próprio do boleto

private:
    Titular pagador_;
    std::string dataVencimento_;
    std::string codigoBarras_;

    static const double TAXA_EMISSAO;
};

const double BoletoBancario::TAXA_EMISSAO = 3.49;

// ============================== CarteiraDigital ==============================

class CarteiraDigital : public FormaPagamento {
public:
    CarteiraDigital(const DadosTransacao& dados, const Titular& titular, double saldoDisponivel)
        : FormaPagamento(dados), titular_(titular), saldoDisponivel_(saldoDisponivel) {}

    bool validar() const override { return getValor() > 0 && saldoDisponivel_ >= getValor(); }

    void processar() override {
        if (validar()) {
            saldoDisponivel_ -= getValor();
            definirStatus(StatusTransacao::APROVADA);
        } else {
            definirStatus(StatusTransacao::RECUSADA);
        }
    }

    double calcularTaxa() const override { return 0.0; }

    std::string getDescricao() const override { return "Carteira Digital de " + titular_.getNome(); }

    double getSaldoDisponivel() const { return saldoDisponivel_; } // próprio da carteira digital

private:
    Titular titular_;
    double saldoDisponivel_;
};

// ================================ Criptomoeda ================================

class Criptomoeda : public FormaPagamento {
public:
    Criptomoeda(const DadosTransacao& dados, const std::string& carteiraDestino,
                const std::string& moeda, double cotacaoNoMomento)
        : FormaPagamento(dados),
          carteiraDestino_(carteiraDestino),
          moeda_(moeda),
          cotacaoNoMomento_(cotacaoNoMomento) {}

    bool validar() const override {
        return getValor() > 0 && carteiraDestino_.size() >= 26 && cotacaoNoMomento_ > 0;
    }

    void processar() override {
        definirStatus(validar() ? StatusTransacao::PROCESSANDO : StatusTransacao::RECUSADA);
    }

    double calcularTaxa() const override {
        return getValor() * 0.005; 
    }

    std::string getDescricao() const override {
        std::ostringstream oss;
        oss << "Criptomoeda (" << moeda_ << ") para a carteira " << carteiraDestino_;
        return oss.str();
    }

    const std::string& getMoeda() const { return moeda_; } // próprio da criptomoeda

private:
    std::string carteiraDestino_;
    std::string moeda_;
    double cotacaoNoMomento_;
};

// ============================ ProcessadorPagamentos ============================

class ProcessadorPagamentos {
public:
    void processarTodos(std::vector<std::unique_ptr<FormaPagamento>>& formasPagamento) const {
        for (std::size_t i = 0; i < formasPagamento.size(); ++i) {
            FormaPagamento& forma = *formasPagamento[i];

            std::printf("----------------------------------------\n");
            std::printf("%s\n", forma.getDescricao().c_str());
            std::printf("Identificador: %s\n", forma.getIdentificador().c_str());
            std::printf("Valor: R$ %.2f\n", forma.getValor());

            if (!forma.validar()) {
                std::printf("Aviso: dados invalidos para esta forma de pagamento.\n");
            }

            forma.processar();

            std::printf("Taxa: R$ %.2f\n", forma.calcularTaxa());
            std::printf("Status: %s\n", statusParaTexto(forma.getStatus()).c_str());
        }
    }
};

// ==================================== main ====================================

int main() {
    std::vector<std::unique_ptr<FormaPagamento>> pagamentos;

    pagamentos.push_back(std::unique_ptr<FormaPagamento>(new CartaoCredito(
        DadosTransacao("TXN-001", 1500.00),
        Titular("Ana Souza", "111.222.333-44"),
        "4111111111111111",
        3)));

    pagamentos.push_back(std::unique_ptr<FormaPagamento>(new Pix(
        DadosTransacao("TXN-002", 250.00),
        "ana.souza@email.com",
        "E00000000202601011200ABCDEFG")));

    pagamentos.push_back(std::unique_ptr<FormaPagamento>(new BoletoBancario(
        DadosTransacao("TXN-003", 890.50),
        Titular("Carlos Lima", "555.666.777-88"),
        "2026-09-10",
        "34191790010104351004791020150008589640000089050")));

    pagamentos.push_back(std::unique_ptr<FormaPagamento>(new CarteiraDigital(
        DadosTransacao("TXN-004", 120.00),
        Titular("Beatriz Alves", "222.333.444-55"),
        500.00)));

    pagamentos.push_back(std::unique_ptr<FormaPagamento>(new Criptomoeda(
        DadosTransacao("TXN-005", 2000.00),
        "bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh",
        "BTC",
        350000.00)));

    ProcessadorPagamentos processador;
    processador.processarTodos(pagamentos);

    return 0;
}