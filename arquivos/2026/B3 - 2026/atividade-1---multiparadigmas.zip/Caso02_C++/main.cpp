#include <cstdio>
#include <chrono>
 
class Particula {
public:
    int id;
    double posX, posY;
    double velX, velY;
    double mass;
 
    Particula(int id, double posX, double posY, double velX, double velY, double mass)
        : id(id), posX(posX), posY(posY), velX(velX), velY(velY), mass(mass) {}
 
    void update() {
        posX += velX;
        posY += velY;
    }
};
 
int main() {
    auto inicio = std::chrono::high_resolution_clock::now();
 
    int totalDeParticulas = 500000;
    Particula** particulas = new Particula*[totalDeParticulas];
 
    for (int i = 0; i < totalDeParticulas; i++) {
        Particula* particula = new Particula(1, 1, 1, 1, 1, 1);
        particulas[i] = particula;
    }
 
    for (int i = 0; i < totalDeParticulas; i++) {
        for (int j = 0; j < 1000; j++) {
            particulas[i]->update();
        }
    }
 
    auto fim = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> tempo = fim - inicio;
 
    printf("%.6f s\n", tempo.count());
 
    for (int i = 0; i < totalDeParticulas; i++) {
        delete particulas[i];
    }
    delete[] particulas;
 
    return 0;
}