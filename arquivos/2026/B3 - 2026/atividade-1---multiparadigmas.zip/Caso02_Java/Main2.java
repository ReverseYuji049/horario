public class Main
{
	public static void main(String[] args) {
	    
	    long inicio = System.nanoTime();
	    
	    int totalDeParticulas = 500000;
		Particula[] particulas = new Particula[totalDeParticulas];
		
		for(int i = 0; i<totalDeParticulas; i++) {
		    Particula particula = new Particula(1, 1, 1, 1, 1, 1);
		    particulas[i] = particula;
		};
		for(int i = 0; i<totalDeParticulas; i++) {
		    for(int j = 0; j<1000; j++) {
		        particulas[i].update();
		    }
		};
		
		long fim = System.nanoTime();
		
		double tempo = (fim-inicio) / 1_000_000_000.0;
		System.out.printf("%.6f s",tempo);
	}
}


