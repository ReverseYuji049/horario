public class Particula {
    int id;
    double posX, posY;
    double velX, velY;
    double mass;
    
    public Particula(int id, double posX, double posY, double velX, double velY,
    double mass) {
        this.id = id;
        this.velX = velX;
        this.velY = velY;
        this.posX = posX;
        this.posY = posY;
        this.mass = mass;
    }
    
    public void update() {
        posX += velX;
        posY += velY;
    }
}