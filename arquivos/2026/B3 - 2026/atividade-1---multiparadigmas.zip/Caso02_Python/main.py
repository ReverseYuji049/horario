import time
 
 
class Particula:
    __slots__ = ("id", "posX", "posY", "velX", "velY", "mass")
 
    def __init__(self, id, posX, posY, velX, velY, mass):
        self.id = id
        self.posX = posX
        self.posY = posY
        self.velX = velX
        self.velY = velY
        self.mass = mass
 
    def update(self):
        self.posX += self.velX
        self.posY += self.velY
 
 
def main():
    inicio = time.perf_counter()
 
    total_de_particulas = 500_000
    particulas = [None] * total_de_particulas
 
    for i in range(total_de_particulas):
        particula = Particula(1, 1, 1, 1, 1, 1)
        particulas[i] = particula
 
    for i in range(total_de_particulas):
        for j in range(1000):
            particulas[i].update()
 
    fim = time.perf_counter()
    tempo = fim - inicio
 
    print(f"{tempo:.6f} s")
 
 
if __name__ == "__main__":
    main()