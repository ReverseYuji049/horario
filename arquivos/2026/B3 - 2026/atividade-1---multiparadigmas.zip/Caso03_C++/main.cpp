#include <algorithm>
#include <chrono>
#include <cstdio>
#include <exception>
#include <fstream>
#include <iomanip>
#include <sstream>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <vector>

// ============================ Data / Venda ============================
struct Data {
    int ano = 0;
    int mes = 0;
    int dia = 0;

    static Data parse(const std::string& texto) {
        Data d;
        if (texto.size() < 10 || texto[4] != '-' || texto[7] != '-') {
            throw std::invalid_argument("Data invalida: " + texto);
        }
        try {
            d.ano = std::stoi(texto.substr(0, 4));
            d.mes = std::stoi(texto.substr(5, 2));
            d.dia = std::stoi(texto.substr(8, 2));
        } catch (const std::exception&) {
            throw std::invalid_argument("Data invalida: " + texto);
        }
        return d;
    }

    std::string toString() const {
        std::ostringstream oss;
        oss << std::setw(4) << std::setfill('0') << ano << "-"
            << std::setw(2) << std::setfill('0') << mes << "-"
            << std::setw(2) << std::setfill('0') << dia;
        return oss.str();
    }

    std::string chaveAnoMes() const {
        std::ostringstream oss;
        oss << ano << "-" << std::setw(2) << std::setfill('0') << mes;
        return oss.str();
    }
};

class Venda {
public:
    Venda(int codigoVenda, const Data& data, const std::string& codigoProduto,
          const std::string& descricao, const std::string& categoria, int qtd,
          double valorUnitario, const std::string& cidade, const std::string& estado)
        : codigoVenda_(codigoVenda),
          data_(data),
          codigoProduto_(codigoProduto),
          descricao_(descricao),
          categoria_(categoria),
          qtd_(qtd),
          valorUnitario_(valorUnitario),
          cidade_(cidade),
          estado_(estado) {}

    int getCodigoVenda() const { return codigoVenda_; }
    const Data& getData() const { return data_; }
    const std::string& getCodigoProduto() const { return codigoProduto_; }
    const std::string& getDescricao() const { return descricao_; }
    const std::string& getCategoria() const { return categoria_; }
    int getQtd() const { return qtd_; }
    double getValorUnitario() const { return valorUnitario_; }
    const std::string& getCidade() const { return cidade_; }
    const std::string& getEstado() const { return estado_; }

    double getFaturamento() const { return qtd_ * valorUnitario_; }

private:
    int codigoVenda_;
    Data data_;
    std::string codigoProduto_;
    std::string descricao_;
    std::string categoria_;
    int qtd_;
    double valorUnitario_;
    std::string cidade_;
    std::string estado_;
};

// ============================== LeitorCSV ==============================

class LeitorCSV {
public:
    std::vector<Venda> carregarVendas(const std::string& nomeArquivo) {
        std::vector<Venda> vendas;

        std::ifstream leitor(nomeArquivo);
        if (!leitor.is_open()) {
            throw std::runtime_error("Nao foi possivel abrir o arquivo: " + nomeArquivo);
        }

        std::string linha;
        std::getline(leitor, linha); // descarta o cabecalho

        while (std::getline(leitor, linha)) {
            if (linha.empty()) {
                continue;
            }

            std::vector<std::string> dados = dividirLinha(linha, ',');
            if (dados.size() < 9) {
                throw std::runtime_error("Linha de CSV invalida: " + linha);
            }

            int codigoVenda = std::stoi(dados[0]);
            Data data = Data::parse(dados[1]);
            std::string codigoProduto = dados[2];
            std::string descricao = dados[3];
            std::string categoria = dados[4];
            int qtd = std::stoi(dados[5]);
            double valorUnitario = std::stod(dados[6]);
            std::string cidade = dados[7];
            std::string estado = dados[8];

            vendas.emplace_back(codigoVenda, data, codigoProduto, descricao, categoria, qtd,
                                 valorUnitario, cidade, estado);
        }

        return vendas;
    }

private:
    static std::vector<std::string> dividirLinha(const std::string& linha, char delimitador) {
        std::vector<std::string> campos;
        std::string atual;
        std::istringstream stream(linha);
        while (std::getline(stream, atual, delimitador)) {
            campos.push_back(atual);
        }
        return campos;
    }
};

// ============================ AnaliseVendas ============================

class AnaliseVendas {
public:
    explicit AnaliseVendas(const std::vector<Venda>& vendas) : vendas_(vendas) {}

    double calcularFaturamentoTotal() const {
        double total = 0;
        for (const Venda& venda : vendas_) {
            total += venda.getFaturamento();
        }
        return total;
    }

    std::unordered_map<std::string, double> calcularFaturamentoPorProduto() const {
        std::unordered_map<std::string, double> resultado;
        for (const Venda& venda : vendas_) {
            resultado[venda.getCodigoProduto()] += venda.getFaturamento();
        }
        return resultado;
    }

    std::string getProdutoMaiorFaturamento() const {
        auto faturamento = calcularFaturamentoPorProduto();
        std::string produtoMaior;
        double maior = 0;
        for (const auto& entrada : faturamento) {
            if (entrada.second > maior) {
                maior = entrada.second;
                produtoMaior = entrada.first;
            }
        }
        return produtoMaior;
    }

    std::unordered_map<std::string, int> calcularQuantidadePorProduto() const {
        std::unordered_map<std::string, int> resultado;
        for (const Venda& venda : vendas_) {
            resultado[venda.getCodigoProduto()] += venda.getQtd();
        }
        return resultado;
    }

    std::vector<std::string> getCincoProdutosMaisVendidos() const {
        auto quantidade = calcularQuantidadePorProduto();
        std::vector<std::pair<std::string, int>> lista(quantidade.begin(), quantidade.end());
        std::sort(lista.begin(), lista.end(),
                  [](const std::pair<std::string, int>& a, const std::pair<std::string, int>& b) {
                      return a.second > b.second;
                  });

        std::vector<std::string> resultado;
        std::size_t limite = std::min<std::size_t>(5, lista.size());
        for (std::size_t i = 0; i < limite; ++i) {
            resultado.push_back(lista[i].first);
        }
        return resultado;
    }

    std::unordered_map<std::string, double> calcularFaturamentoPorCategoria() const {
        std::unordered_map<std::string, double> resultado;
        for (const Venda& venda : vendas_) {
            resultado[venda.getCategoria()] += venda.getFaturamento();
        }
        return resultado;
    }

    std::string getCategoriaMaiorFaturamento() const {
        auto faturamento = calcularFaturamentoPorCategoria();
        std::string categoriaMaior;
        double maior = 0;
        for (const auto& entrada : faturamento) {
            if (entrada.second > maior) {
                maior = entrada.second;
                categoriaMaior = entrada.first;
            }
        }
        return categoriaMaior;
    }

    double calcularTicketMedio() const {
        if (vendas_.empty()) {
            return 0;
        }
        return calcularFaturamentoTotal() / static_cast<double>(vendas_.size());
    }

    std::unordered_map<std::string, double> calcularFaturamentoPorCidade() const {
        std::unordered_map<std::string, double> resultado;
        for (const Venda& venda : vendas_) {
            resultado[venda.getCidade()] += venda.getFaturamento();
        }
        return resultado;
    }

    std::string getCidadeMaiorFaturamento() const {
        auto faturamento = calcularFaturamentoPorCidade();
        std::string cidadeMaior;
        double maior = 0;
        for (const auto& entrada : faturamento) {
            if (entrada.second > maior) {
                maior = entrada.second;
                cidadeMaior = entrada.first;
            }
        }
        return cidadeMaior;
    }

    std::unordered_map<std::string, double> calcularFaturamentoPorEstado() const {
        std::unordered_map<std::string, double> resultado;
        for (const Venda& venda : vendas_) {
            resultado[venda.getEstado()] += venda.getFaturamento();
        }
        return resultado;
    }

    std::string getEstadoMaiorFaturamento() const {
        auto faturamento = calcularFaturamentoPorEstado();
        std::string estadoMaior;
        double maior = 0;
        for (const auto& entrada : faturamento) {
            if (entrada.second > maior) {
                maior = entrada.second;
                estadoMaior = entrada.first;
            }
        }
        return estadoMaior;
    }

    std::unordered_map<std::string, double> calcularFaturamentoPorMes() const {
        std::unordered_map<std::string, double> resultado;
        for (const Venda& venda : vendas_) {
            resultado[venda.getData().chaveAnoMes()] += venda.getFaturamento();
        }
        return resultado;
    }

    std::unordered_map<std::string, int> calcularQuantidadePorCategoria() const {
        std::unordered_map<std::string, int> resultado;
        for (const Venda& venda : vendas_) {
            resultado[venda.getCategoria()] += venda.getQtd();
        }
        return resultado;
    }

    double calcularMediaFaturamentoProdutos() const {
        auto faturamento = calcularFaturamentoPorProduto();
        if (faturamento.empty()) {
            return 0;
        }
        double total = 0;
        for (const auto& entrada : faturamento) {
            total += entrada.second;
        }
        return total / static_cast<double>(faturamento.size());
    }

    std::vector<std::string> getProdutosAcimaDaMedia() const {
        auto faturamento = calcularFaturamentoPorProduto();
        double media = calcularMediaFaturamentoProdutos();
        std::vector<std::string> resultado;
        for (const auto& entrada : faturamento) {
            if (entrada.second > media) {
                resultado.push_back(entrada.first);
            }
        }
        return resultado;
    }

private:
    std::vector<Venda> vendas_;
};

// ================================ main =================================

namespace {
std::string ouNull(const std::string& valor) { return valor.empty() ? "null" : valor; }
} // namespace

int main() {
    try {
        auto inicio = std::chrono::high_resolution_clock::now();

        LeitorCSV leitor;
        std::vector<Venda> vendas = leitor.carregarVendas("vendas.csv");

        AnaliseVendas analisador(vendas);

        double faturamentoTotal = analisador.calcularFaturamentoTotal();
        std::string produtoMaior = analisador.getProdutoMaiorFaturamento();
        std::vector<std::string> cincoMaisVendidos = analisador.getCincoProdutosMaisVendidos();
        std::string categoriaMaior = analisador.getCategoriaMaiorFaturamento();
        double ticketMedio = analisador.calcularTicketMedio();
        std::string cidadeMaior = analisador.getCidadeMaiorFaturamento();
        std::string estadoMaior = analisador.getEstadoMaiorFaturamento();
        auto faturamentoMes = analisador.calcularFaturamentoPorMes();
        auto quantidadeCategoria = analisador.calcularQuantidadePorCategoria();
        std::vector<std::string> produtosAcimaMedia = analisador.getProdutosAcimaDaMedia();

        auto fim = std::chrono::high_resolution_clock::now();
        double tempoMs = std::chrono::duration<double, std::milli>(fim - inicio).count();

        std::printf("===== RESULTADOS =====\n");
        std::printf("Registros: %zu\n", vendas.size());
        std::printf("1. Faturamento total: R$ %.2f\n", faturamentoTotal);
        std::printf("2. Produto com maior faturamento: %s\n", ouNull(produtoMaior).c_str());

        std::printf("3. Cinco produtos mais vendidos:\n");
        for (const std::string& produto : cincoMaisVendidos) {
            std::printf("- %s\n", produto.c_str());
        }

        std::printf("4. Categoria com maior faturamento: %s\n", ouNull(categoriaMaior).c_str());
        std::printf("5. Ticket medio: R$ %.2f\n", ticketMedio);
        std::printf("6. Cidade com maior faturamento: %s\n", ouNull(cidadeMaior).c_str());
        std::printf("7. Estado com maior faturamento: %s\n", ouNull(estadoMaior).c_str());

        std::printf("8. Faturamento por mes:\n");
        for (const auto& entrada : faturamentoMes) {
            std::printf("%s: R$ %.2f\n", entrada.first.c_str(), entrada.second);
        }

        std::printf("9. Quantidade por categoria:\n");
        for (const auto& entrada : quantidadeCategoria) {
            std::printf("%s: %d unidades\n", entrada.first.c_str(), entrada.second);
        }

        std::printf("10. Produtos acima da media:\n");
        for (const std::string& produto : produtosAcimaMedia) {
            std::printf("- %s\n", produto.c_str());
        }

        std::printf("Tempo de execucao: %.6f ms\n", tempoMs);
    } catch (const std::exception& e) {
        std::printf("Erro: %s\n", e.what());
    }

    return 0;
}